package com.jee.topachat;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TopachatApplicationTests {

	@Test
	void contextLoads() {
	}

}
